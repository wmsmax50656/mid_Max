document.addEventListener('DOMContentLoaded', function() {
    const sections = document.querySelectorAll('section');

    // 스크롤 이벤트 리스너 추가
    window.addEventListener('scroll', () => {
        let current = '';

        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (window.pageYOffset >= sectionTop - sectionHeight / 3) {
                current = section.getAttribute('id');
            }
        });

        console.log(current);
    });
});